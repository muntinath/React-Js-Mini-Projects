# Continued Create Note APP V1


# CSS styles are modified.

# Previous version was  non responsive . Made it responsive.

# Material UI is used for icons.


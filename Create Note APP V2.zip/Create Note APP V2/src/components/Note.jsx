import React from 'react'
import { Button } from '@material-ui/core'
import DeleteIcon from '@material-ui/icons/Delete';

export default function Note(props) {

function handleClick(){
    props.onDelete(props.id)
}

    return (
        <div className="note">
            <h3 className="note_title">{props.title}</h3>
            <p className="note_content" >{props.content}</p>
            <Button  style={{ color:"red" , width:"1rem"  }} onClick={handleClick} className="noteBtn"><DeleteIcon style={{ color:"red" }} /></Button>
        </div>
    )
}

import React,{useState} from 'react'
import AddIcon from '@material-ui/icons/Add';



export default function Form(props) {
    const [note,setNote]=useState({title:"",content:""})
    function handleChange(e){
        const {name,value}=e.target
        setNote(prevNote=>{
            return {...prevNote,[name]:value}
        })
        }

        function handleSubmit(event){
            props.onAdd(note)
            setNote({title:"",content:""})
            event.preventDefault()
        }

    return (
        <div className="form">
            <form>
                    <input onChange={handleChange} name="title" placeholder="Enter a title" value={note.title} /><br />
                    <textarea onChange={handleChange} name="content" placeholder="Enter your notes" value={note.content}  rows="3" /><br/>
                    <button onClick={handleSubmit} ><AddIcon /></button>
            </form>
        </div>
    )
}

import React from 'react'

export default function Footer() {

    var date=new Date().getFullYear()

    return (
        <div className="footer">
            copyright©{date}
        </div>
    )
}
